# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '813fcf83b801ed450ecd0f5c5df70a89dbf4b5e8da59fb17fdc0827eb49a9337852e93ac10cb19320e96e3c279da9f85f54d7b7d81c5ada1edc4769a13ea6a1f'