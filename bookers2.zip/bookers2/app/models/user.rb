class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  has_many :books, dependent: :destroy
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
  attachment :profile_image
  #2文字より少ない時と２０文字より多い時にメッセージ
  validates :name, presence: true, uniqueness: true, length: {
    minimum: 2, too_short: "Name is too short (minimum is 2 characters)" ,
    maximum: 20, too_long: "Name is too long (maximum is 20 characters)"
  }
  #イントロダクションは最大５０文字まで
  validates :introduction, length: { maximum: 50, message: "Introduction is too long (maximum is 50 characters)" }
end
