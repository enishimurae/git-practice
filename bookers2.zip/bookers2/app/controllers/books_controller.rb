class BooksController < ApplicationController

def new
  @book = Book.new
end

def create
   @book = Book.new(book_params) #これまで学習してきた記述
   @book.user_id = current_user.id #投稿したユーザーに紐づける
  if @book.save
     redirect_to @book, notice: "You have created book successfully."
  else
      @users = User.all
      @books = Book.all # @booksを設定
      @user = current_user
      render :index
  end
end

def index
  @books = Book.all
  @book = Book.new
  @user = current_user
end

def show
  @book = Book.new #左側のフォームの入力用
  @book_new = Book.find(params[:id]) #右の表示用
  @user = @book_new.user # 本を投稿したユーザーを取得
  @books = Book.all # 一覧表示に使う
end

def edit
  @book = Book.find(params[:id]) #Book を編集しようとしているユーザーを取得する
  if @book.user == current_user #そのユーザーが、編集対象の Book を投稿したユーザーと同じであるかを調べる
    render :edit
  else
     @books = Book.all
     redirect_to books_path
  end
end

def update
  @book = Book.find(params[:id])
  if @book.update(book_params)
    redirect_to @book, notice: 'You have updated book successfully.'
  else
    render :edit
  end
end

def destroy
  @book = Book.find(params[:id])
  @book.destroy
  redirect_to books_path
end

private

def book_params
  params.require(:book).permit(:title, :body)
end


end